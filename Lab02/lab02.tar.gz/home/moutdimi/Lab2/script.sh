#!/bin/bash

#Date:

date

#Current Date In Seconds

current_time=$(date +%s)
let current_time_double=current_time*2


echo "The current time is: $current_time "
echo "The current Double Time is: $current_time_double"

for i in {1..20}; do 
	echo "Number: $i"
done
 


